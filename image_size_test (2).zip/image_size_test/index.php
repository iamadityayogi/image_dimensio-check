<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="">
        <div  class="container">
            <input type="file" name="image" id="fileUpload">
        </div>
        <button type="submit" id="submitBtn" name="submitBtn" value="submitBtn">Submit</button>
    </form>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    var _URL = window.URL || window.webkitURL;
    $("#fileUpload").change(function(e) {
        var file, img;
        if ((file = this.files[0])) {
            img = new Image();
            img.onload = function() {
                alert(this.width);
                alert(this.height);
                if (this.width >= 400 && this.width <= 500 || this.height >= 260 && this.height <= 325) {
                    $('#span_error2').html('');
                    submitBtn.disabled = false;
                } else {
                    $('#span_error2').html('Not A Valid Dimensions.');
                    submitBtn.disabled = true;
                    alert('not a valid file size');
                }
            };
            img.onerror = function() {
                alert( "not a valid file: " + file.type);
            };
            img.src = _URL.createObjectURL(file);
        }
    });
</script>